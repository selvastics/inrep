# =============================================================================
# PSYCHOLOGICAL STUDY EXAMPLE - READY TO RUN
# =============================================================================
# This example demonstrates the new Monochrome theme with a psychological study
# on R package testing experience. Simply run this entire script!

# Load required libraries
library(inrep)

# Print welcome message
cat("=============================================================================\n")
cat("PSYCHOLOGICAL STUDY ON R PACKAGE TESTING EXPERIENCE\n")
cat("=============================================================================\n")
cat("Using inrep package with the new Monochrome theme\n")
cat("Study Duration: 20 minutes\n")
cat("Questions: 6 Likert-scale items\n")
cat("Demographics: Age range and R experience\n")
cat("=============================================================================\n\n")

# =============================================================================
# 1. ITEM BANK CREATION
# =============================================================================
cat("1. Creating item bank...\n")

# Create the psychological study item bank
psychological_items <- data.frame(
  item_id = 1:6,
  
  # Research questions about R testing experience
  item_text = c(
    "I feel confident in my ability to write effective unit tests using testthat.",
    "Using devtools to manage and test R packages is intuitive and efficient.",
    "Interpreting code coverage reports from covr helps me improve my testing strategy.",
    "Testing R packages reduces my stress when preparing for a package release.",
    "I feel motivated to incorporate regular testing into my R package development process.",
    "The documentation for testthat is clear and supports my testing needs."
  ),
  
  # Explanations for each question (shown in results)
  explanation = c(
    "Confidence in testing skills can enhance code quality and reduce development errors.",
    "Ease of use in testing workflows impacts developer productivity and adoption.",
    "Clear coverage reports enable targeted improvements in test coverage.",
    "Effective testing can alleviate concerns about introducing bugs in production.",
    "Motivation to test regularly correlates with higher code reliability and quality.",
    "Clear documentation is critical for effective use of testing tools."
  ),
  
  # IRT parameters for Graded Response Model (5-point Likert scale)
  a = c(1.8, 1.6, 1.4, 1.7, 1.9, 1.5),  # Discrimination parameters
  b1 = c(-2.1, -1.8, -2.0, -1.9, -2.2, -1.7),  # Threshold 1
  b2 = c(-0.8, -0.6, -0.9, -0.7, -1.0, -0.5),  # Threshold 2  
  b3 = c(0.2, 0.1, 0.3, 0.0, 0.4, 0.2),        # Threshold 3
  b4 = c(1.1, 1.0, 1.2, 0.9, 1.3, 1.1),        # Threshold 4
  
  # Response options for all items
  response_options = I(rep(list(c(
    "Strongly Disagree",
    "Disagree", 
    "Neutral",
    "Agree",
    "Strongly Agree"
  )), 6)),
  
  stringsAsFactors = FALSE
)

cat("✓ Item bank created with", nrow(psychological_items), "items\n")

# =============================================================================
# 2. STUDY CONFIGURATION
# =============================================================================
cat("2. Creating study configuration...\n")

# Create comprehensive study configuration
study_config <- create_study_config(
  # Basic study information
  name = "Psychological Study on R Package Testing Experience",
  study_key = "r_testing_psych_2025",
  
  # Use the new Monochrome theme (case-insensitive)
  theme = "Monochrome",
  
  # Demographics collection
  demographics = c("age_range", "r_experience"),
  input_types = list(
    age_range = "radio",
    r_experience = "radio"
  ),
  
  # Psychometric model
  model = "GRM",  # Graded Response Model for Likert scales
  
  # Study design (fixed questionnaire, not adaptive)
  adaptive = FALSE,
  max_items = 6,
  min_items = 6,
  
  # Session management
  session_save = TRUE,
  session_timeout = 20,  # 20-minute timer
  
  # UI configuration
  response_ui_type = "radio",
  progress_style = "bar",
  
  # Response validation
  response_validation_fun = function(response) {
    !is.null(response) && nzchar(as.character(response))
  },
  
  # Demographic question configurations
  demographic_configs = list(
    age_range = list(
      question = "What is your age range?",
      options = c("18-24", "25-34", "35-44", "45-54", "55+"),
      required = FALSE
    ),
    r_experience = list(
      question = "How many years have you been using R for package development?",
      options = c("Less than 1 year", "1-3 years", "3-5 years", "5+ years"),
      required = FALSE
    )
  ),
  
  # Custom instructions
  instructions = list(
    welcome = paste(
      "Thank you for participating in this psychological study conducted by researchers",
      "investigating the experiences of R developers in package testing. This study explores",
      "how tools such as testthat, covr, and devtools influence developer confidence, stress,",
      "and motivation. Your participation will contribute to improving tools and support for",
      "the R community."
    ),
    
    purpose = "To examine psychological factors affecting R package testing workflows.",
    
    duration = "Approximately 15-20 minutes.",
    
    structure = paste(
      "The study consists of a consent form, demographic questions, and a main survey",
      "with Likert-scale questions. All questions are optional, but complete responses",
      "are appreciated."
    ),
    
    confidentiality = paste(
      "Your responses are anonymous and will be used solely for research purposes.",
      "Data will be stored securely and reported in aggregate form."
    ),
    
    consent_text = paste(
      "This study involves completing a survey about your experiences with R package",
      "testing tools. Participation is voluntary, and you may withdraw at any time by",
      "closing this window. Your responses will be anonymized and used for academic",
      "research only. There are no known risks, and your participation will help advance",
      "knowledge in software development psychology."
    ),
    
    contact = "For questions, contact the research team at research@example.edu."
  ),
  
  # Personalized feedback function
  recommendation_fun = function(theta, demographics) {
    if (is.null(theta) || length(theta) == 0) {
      return("Thank you for participating in this psychological study on R package testing.")
    }
    
    # Calculate average response tendency
    avg_score <- mean(theta, na.rm = TRUE)
    
    # Provide personalized feedback based on responses
    if (avg_score >= 1.0) {
      return(paste(
        "Your responses indicate high confidence and positive experiences with R testing tools.",
        "Consider sharing your expertise with the community through tutorials or mentoring.",
        "Your positive attitude toward testing contributes to the overall quality of R packages.",
        "You might be interested in advanced testing techniques or contributing to testing tools."
      ))
    } else if (avg_score >= 0.0) {
      return(paste(
        "Your responses show moderate comfort with R testing tools.",
        "Consider exploring advanced testing techniques or joining R testing communities for support.",
        "Resources like the R Testing Guide, testthat documentation, and online forums may be helpful.",
        "Building testing skills gradually can improve your development workflow."
      ))
    } else {
      return(paste(
        "Your responses suggest room for growth in R testing practices.",
        "Consider starting with basic testthat tutorials and gradually building your testing skills.",
        "The R community offers many resources for learning testing best practices.",
        "Don't hesitate to ask questions in R forums or attend testing workshops."
      ))
    }
  }
)

cat("✓ Study configuration created with Monochrome theme\n")

# =============================================================================
# 3. VALIDATION
# =============================================================================
cat("3. Validating configuration...\n")

# Validate item bank
validation_result <- validate_item_bank(psychological_items, model = "GRM")
if (validation_result$valid) {
  cat("✓ Item bank validation passed\n")
} else {
  cat("✗ Item bank validation failed:\n")
  cat(validation_result$errors, "\n")
}

# Test theme loading
theme_css <- load_theme_css("Monochrome")
if (nchar(theme_css) > 1000) {
  cat("✓ Monochrome theme loaded successfully (", nchar(theme_css), " characters)\n")
} else {
  cat("✗ Monochrome theme loading failed\n")
}

# Test case-insensitive theme matching
cat("✓ Case-insensitive theme matching:\n")
test_themes <- c("monochrome", "MONOCHROME", "Monochrome", "MonoChrome")
for (theme in test_themes) {
  result <- validate_theme_name(theme)
  cat("  ", theme, "->", result, "\n")
}

# =============================================================================
# 4. LAUNCH INSTRUCTIONS
# =============================================================================
cat("\n=============================================================================\n")
cat("READY TO LAUNCH!\n")
cat("=============================================================================\n")
cat("To start the psychological study, run the following command:\n\n")
cat("launch_study(\n")
cat("  config = study_config,\n")
cat("  item_bank = psychological_items,\n")
cat("  port = 3838,\n")
cat("  launch_browser = TRUE\n")
cat(")\n\n")
cat("The study will open in your default web browser with the Monochrome theme.\n")
cat("=============================================================================\n")

# =============================================================================
# 5. OPTIONAL: AUTOMATIC LAUNCH
# =============================================================================
# Uncomment the following lines to automatically launch the study:

# cat("Launching study in 3 seconds...\n")
# Sys.sleep(3)
# 
# launch_study(
#   config = study_config,
#   item_bank = psychological_items,
#   port = 3838,
#   launch_browser = TRUE
# )

# =============================================================================
# 6. ADDITIONAL INFORMATION
# =============================================================================
cat("\nADDITIONAL INFORMATION:\n")
cat("- Available themes:", paste(get_builtin_themes(), collapse = ", "), "\n")
cat("- Study uses Graded Response Model (GRM) for Likert scales\n")
cat("- Timer: 20 minutes with warnings at 2 minutes remaining\n")
cat("- Progress tracking with elegant animations\n")
cat("- Results can be downloaded as text file\n")
cat("- Fully accessible (WCAG 2.1 AA compliant)\n")
cat("- Responsive design for all devices\n")

cat("\nMonochrome theme features:\n")
cat("- Elegant black and white design\n")
cat("- Google Fonts (Lora + Inter)\n") 
cat("- Sophisticated animations\n")
cat("- High contrast accessibility\n")
cat("- Print-friendly styles\n")

cat("\n=============================================================================\n")
cat("EXAMPLE COMPLETE - READY TO RUN!\n")
cat("=============================================================================\n")
